Action1()
{

	web_url("webtours", 
		"URL=http://localhost:1080/webtours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("fwlink", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=251136", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("fwlink_2", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=517287", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.s-microsoft.com/static/fonts/segoe-ui/cyrillic/normal/latest.eot?", "Referer=https://www.microsoft.com/ru-ru/welcomeie11/", ENDITEM, 
		"Url=https://www.microsoft.com/mwf/_h/v3.07/mwf.app/fonts/mwfmdl2-v3.07.woff", "Referer=https://www.microsoft.com/ru-ru/welcomeie11/", ENDITEM, 
		"Url=https://c.s-microsoft.com/static/fonts/segoe-ui/cyrillic/light/latest.eot?", "Referer=https://www.microsoft.com/ru-ru/welcomeie11/", ENDITEM, 
		"Url=https://www.microsoft.com/favicon.ico", "Referer=", ENDITEM, 
		"Url=https://c.s-microsoft.com/ru-ru/CMSImages/ms-icons-v2.jpg?version=86273b5d-da96-139b-36a4-e9f04b7a485d", "Referer=https://www.microsoft.com/ru-ru/welcomeie11/", ENDITEM, 
		LAST);

	web_add_cookie("MUID=2C5F5C6B064B68220D53511C024B6CC4; DOMAIN=login.live.com");

	web_add_cookie("NAP=V=1.9&E=1661&C=5CoNy8HRzUlrRzE69FLE8bNKA3-UEKZHDM_vyTkrBc4wCZjoK4P74Q&W=1; DOMAIN=login.live.com");

	web_add_cookie("ANON=A=21FF99E5E0BC1D135E781EA0FFFFFFFF&E=16bb&W=1; DOMAIN=login.live.com");

	web_add_cookie("WLOpt=credtype=1&act=[1]; DOMAIN=login.live.com");

	web_add_cookie("MSPCID=5ea99ddcb8eaa078; DOMAIN=login.live.com");

	web_add_cookie("MSPPre=alexperchchannel@outlook.com|5ea99ddcb8eaa078||; DOMAIN=login.live.com");

	web_add_cookie("CAW=%3CEncryptedData%20xmlns%3D%22http://www.w3.org/2001/04/xmlenc%23%22%20Id%3D%22BinaryDAToken1%22%20Type%3D%22http://www.w3.org/2001/04/xmlenc%23Element%22%3E%3CEncryptionMethod%20Algorithm%3D%22http://www.w3.org/2001/04/xmlenc%23tripledes-cbc%22%3E%3C/EncryptionMethod%3E%3Cds:KeyInfo%20xmlns:ds%3D%22http://www.w3.org/2000/09/xmldsig%23%22%3E%3Cds:KeyName%3Ehttp://Passport.NET/STS%3C/ds:KeyName%3E%3C/ds:KeyInfo%3E%3CCipherData%3E%3CCipherValue%3ECSp/CVVRM4Yb/"
		"LK3k1mwClgejrqU9jROlk9UD4mb8WEZ2CCd8inP5ABOKYN73VtJVnuTnAU7M%2BZNdpKr9mUtUkBNtmlYz37536Vnt5Ss9SoF0eatwovhMt8UfIC2HtAsw%2BoeTl4guYrtsrnmlEPOr22IhTc1yss4T5ujpvrwdjxlCtHDC0jJ4fn1QvDEGeM9VCk/ghyfYwShl5E9YMBBSBA4mnUDYWJOjD/vYRG7gdvuZt6p28N%2BTS0L7QK6OY7T1i/gTZDtcKLMkmj6dOB98AZ2cI9HIKvKmoNpUMRLmcGIwY9g9UUzCl2kyboGvbf31pBlrnDzVLZhjjBRplZ8nUWdvDlMbmPGATkf8U/wB6NAX5Miyhm5HVdzIL0TE5RDNs/hhRkz/5QdSEjZk2CVrU8RklemN6mjxWS/a8FJRq5U6EHP19kIEzqsBlBautnJ/C/YooTxzDkdDuZRYha3uvf1B%2BJmpkLUGX5E7gnEFlw/"
		"DozXNlDxZFijo1lEHQ5YABmXHVAIqww4Ni2pvdaQ5pRtNVUQmtZJubLT5z7qXopm8GSM6L/AF8LFsqG0RBZ8I5ASbbFc7NjKItbNvGS9V5C9BCBJYRDNNAuXrmWtT9rNIA3hNXK5Yqod61xrFDMPbZ1dj79gZ8R1R5g7y1I8ceibGah5w4oRepze6dTq6viZRl98xepZJCNETIkeOARfyA%3D%3D%3C/CipherValue%3E%3C/CipherData%3E%3C/EncryptedData%3E; DOMAIN=login.live.com");

	web_add_cookie("DIDC=ct%3D1563812237%26hashalg%3DSHA256%26bver%3D18%26appid%3DDefault%26da%3D%253CEncryptedData%2520xmlns%253D%2522http://www.w3.org/2001/04/xmlenc%2523%2522%2520Id%253D%2522devicesoftware%2522%2520Type%253D%2522http://www.w3.org/2001/04/xmlenc%2523Element%2522%253E%253CEncryptionMethod%2520Algorithm%253D%2522http://www.w3.org/2001/04/xmlenc%2523tripledes-cbc%2522%253E%253C/EncryptionMethod%253E%253Cds:KeyInfo%2520xmlns:ds%253D%2522http://www.w3.org/2000/09/"
		"xmldsig%2523%2522%253E%253Cds:KeyName%253Ehttp://Passport.NET/STS%253C/ds:KeyName%253E%253C/ds:KeyInfo%253E%253CCipherData%253E%253CCipherValue%253ECecxfa%252BaRMwOrkU/CeqFq3iqg5sgp1k4scVrjWsZYHhgXJKdvjYh69TxHYZdj9LpacBO7tCg8CM/jDWhsdXQTK/GeQuZ7gjjGfHB3vaarM0wE0pSn0FFaOjOzrtzVLSwBldfa8/3uLH83S7z8NmFz1bPYYCo4JEIqM6MyN5mwt9MlMFJvsFwSJvvdRAaZOYWKMJmMeIYczGBhXF2f92b/"
		"eJjDPYEFKVa3Ida0GA6COw4ko7h2XcWG4eRJrQ1XV3dtAH52Pd6qcfp1blXhMG8ztkbOVQGjai7D2QS30Qwv9ivj42nHHGSPFjQLdy5IVs5xfKcWRpIAhW2JKUMBAuV3jHCeDEh9i71WhQSwa1pd0V2tM7L4gpdEhhc41vwP4LMhDOSKaJ4EDEaZe4W90D1jy9eX3F9sNQfOc44qpYZKTiORrRwrHs%252B0yiXN%252Bhx7CjGQKE9J6YKFJBQf%252BWIyoJhQAEL62feRc8UoajyiZ9dPSXfV8XsDm4k9dQk3O27xTG6NEosgG8a7aMuI8Tb%252BADuEKC2uf%252BYLSzNhrQ1/"
		"bHjVzgOWlHh3tdpgDLWVsmSWAtZzUBu7UpIvq9yLK8Yd18RmyI0cedqZILNEkfPPV3DxJhxCzePWXd3xA3IvWRdQVu2pngKKb4i8Fl6bK%252BilwJJI%252BDjs5MjXmC48N1OWjmGU0q2gvdd%252BXs9aiLEr2zgUlR6/bqkg0O5acsyFoHT3GxR%252BXBb1MM4RfofSPQNbQk9FQpS4rLCw4e/PeGg2glqe7GaIDTBgjK3BWwGpx/4IjTZV7jkm%252BAseWDmbDkfFcOGnENo%253C/CipherValue%253E%253C/CipherData%253E%253C/EncryptedData%253E%26nonce%3DY716HbDJFuQMjgmtL46hcV8daaXx%252F%252BCr%26hash%3DxpkBPD%252Bq1VJgD34b6ZjohSDeN6E%252BD1tz%252BQcyHAUQW0g%253D%26dd%3D1; DOMAIN=login.live.com");

	web_add_cookie("DIDCL=ct%3D1563812237%26hashalg%3DSHA256%26bver%3D18%26appid%3DDefault%26da%3D%253CEncryptedData%2520xmlns%253D%2522http://www.w3.org/2001/04/xmlenc%2523%2522%2520Id%253D%2522devicesoftware%2522%2520Type%253D%2522http://www.w3.org/2001/04/xmlenc%2523Element%2522%253E%253CEncryptionMethod%2520Algorithm%253D%2522http://www.w3.org/2001/04/xmlenc%2523tripledes-cbc%2522%253E%253C/EncryptionMethod%253E%253Cds:KeyInfo%2520xmlns:ds%253D%2522http://www.w3.org/2000/09/"
		"xmldsig%2523%2522%253E%253Cds:KeyName%253Ehttp://Passport.NET/STS%253C/ds:KeyName%253E%253C/ds:KeyInfo%253E%253CCipherData%253E%253CCipherValue%253ECecxfa%252BaRMwOrkU/CeqFq3iqg5sgp1k4scVrjWsZYHhgXJKdvjYh69TxHYZdj9LpacBO7tCg8CM/jDWhsdXQTK/GeQuZ7gjjGfHB3vaarM0wE0pSn0FFaOjOzrtzVLSwBldfa8/3uLH83S7z8NmFz1bPYYCo4JEIqM6MyN5mwt9MlMFJvsFwSJvvdRAaZOYWKMJmMeIYczGBhXF2f92b/"
		"eJjDPYEFKVa3Ida0GA6COw4ko7h2XcWG4eRJrQ1XV3dtAH52Pd6qcfp1blXhMG8ztkbOVQGjai7D2QS30Qwv9ivj42nHHGSPFjQLdy5IVs5xfKcWRpIAhW2JKUMBAuV3jHCeDEh9i71WhQSwa1pd0V2tM7L4gpdEhhc41vwP4LMhDOSKaJ4EDEaZe4W90D1jy9eX3F9sNQfOc44qpYZKTiORrRwrHs%252B0yiXN%252Bhx7CjGQKE9J6YKFJBQf%252BWIyoJhQAEL62feRc8UoajyiZ9dPSXfV8XsDm4k9dQk3O27xTG6NEosgG8a7aMuI8Tb%252BADuEKC2uf%252BYLSzNhrQ1/"
		"bHjVzgOWlHh3tdpgDLWVsmSWAtZzUBu7UpIvq9yLK8Yd18RmyI0cedqZILNEkfPPV3DxJhxCzePWXd3xA3IvWRdQVu2pngKKb4i8Fl6bK%252BilwJJI%252BDjs5MjXmC48N1OWjmGU0q2gvdd%252BXs9aiLEr2zgUlR6/bqkg0O5acsyFoHT3GxR%252BXBb1MM4RfofSPQNbQk9FQpS4rLCw4e/PeGg2glqe7GaIDTBgjK3BWwGpx/4IjTZV7jkm%252BAseWDmbDkfFcOGnENo%253C/CipherValue%253E%253C/CipherData%253E%253C/EncryptedData%253E%26nonce%3DY716HbDJFuQMjgmtL46hcV8daaXx%252F%252BCr%26hash%3DxpkBPD%252Bq1VJgD34b6ZjohSDeN6E%252BD1tz%252BQcyHAUQW0g%253D%26dd%3D1; DOMAIN=login.live.com");

	lr_think_time(5);

	web_url("silentauth", 
		"URL=https://www.microsoft.com/en-us/silentauth", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.microsoft.com/ru-ru/welcomeie11/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("23");

	web_submit_data("silentauth_2", 
		"Action=https://www.microsoft.com/en-us/silentauth?silentauth=msa&wa=wsignin1.0", 
		"Method=POST", 
		"TargetFrame=_self", 
		"RecContentType=text/html", 
		"Referer=https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&checkda=1&ct=1563812237&rver=7.1.6819.0&wp=MBI_SSL&wreply=https%3a%2f%2fwww.microsoft.com%2fen-us%2fsilentauth%3fsilentauth%3dmsa&lc=1033&id=74335&aadredir=1", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=NAPExp", "Value=Wed, 30-Oct-2019 23:17:23 GMT", ENDITEM, 
		"Name=lp", "Value=2mKW!53foBeaoB2CHpvXml*Ak9J3XjMQCoQbrRAQUM6eh7N84bsZgyN76*C904dywcYe5sWRbxsFZ!jdlRr8goqDp7vzKn2otD*CEfzOM54J4SSBw3DnWn!OoRPfrOY6gHc!UOtd6nITiF*1F!gpgrE0thIj6XQXY8IPlTSCf2iFn6GxTOrSLKJuxd4O9!oUOyq7zOggEGfAmiYT6dLrFWaYLfwXZKdc4LIoucbW1vcRLO9qVVm7OnS8KfdyyDhSIu", ENDITEM, 
		"Name=pprid", "Value=5ea99ddcb8eaa078", ENDITEM, 
		"Name=lt", "Value=2TJfqt6KUAvBwseJ!0IGZPQxJBTAshD2Bx425pNf3bdvQQfWdyVOCtrofKMu1C3Mo22WqF80E2!5NJvVwqx82YFPj6XzBrgQb4j44afUshH8dD4B0Z6AUTK9I4yFKb*292FKT04jcFfy80LSfTJs65tQ$$", ENDITEM, 
		"Name=NAP", "Value=V%3D1.9%26E%3D1661%26C%3D5CoNy8HRzUlrRzE69FLE8bNKA3-UEKZHDM_vyTkrBc4wCZjoK4P74Q%26W%3D1", ENDITEM, 
		"Name=ANON", "Value=A%3D21FF99E5E0BC1D135E781EA0FFFFFFFF%26E%3D16bb%26W%3D1", ENDITEM, 
		"Name=ANONExp", "Value=Sat, 08-Feb-2020 00:17:23 GMT", ENDITEM, 
		"Name=t", "Value=GABoAgMAAAAEgAAADAAgy5TCjSK8Bpe03BPMEoMx+41MkpbW4I26hxFEN3E+fU4AAdPmGd1IOfvX4gI0jBqFzuD0HWB7DG3hg98vz9XpM7qQt3vJtBxoBuxWZYkmeWXppGgOKa+DKG7q3YVwmb93KnXsxUTs3gE879WavW1JgTg2DLICKR1uyzCMqixjhDVs5BxT0dQ72VtsLQdyAbEkN0bHsUEZfp7yvnzBSIhjxlUHS1kV2kjjzaAy58YpCuH5joGJi1zC6sCwF5+8AdgX3uzvY8B/89wIviLO/HlRAmCq6EsFqQOUKApSw1dyWblTxGhjlriUdREc8CkvCAP53DpKxxRr15hzZsk4MjhEd+c9D8zEseougBuPZF+DZ7NHCBerw8iVUvLPNSbanC6w7y81AXsANQH+"
		"fwMAujVrB43hNV33mCtdXyIBAAoQIAAQHQBhbGV4cGVyY2hjaGFubmVsQG91dGxvb2suY29tAHUAAClhbGV4cGVyY2hjaGFubmVsJW91dGxvb2suY29tQHBhc3Nwb3J0LmNvbQAAABFSVQAAAAAAAAQZAgAAjOtVQBAGQwAO0JDQu9C10LrRgdC10LkAENCf0LXRgNGH0LXQvdC60L4AAAAAAAAAAAAAAAAAAAAAAAC46qB4Xqmd3AAAjeE1XV5HrF0AAAAAAAAAAAAAAAANADEwOS43My45LjI1MQAFAQAAAADAGACAJ36hBAEAAAAAAAAAAAAAAAAAAAAA7uWG9bID/ykCQBgAHND9of6/GACYEPvYAAAAAAAAAAAAAAAAAAD9vyMAp1o9ggAAAAADAA==", ENDITEM, 
		LAST);

	lr_think_time(9);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=126675.756662616zfVfiitpcDDDDDDDDQAQfpDAft", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=70", ENDITEM, 
		"Name=login.y", "Value=5", ENDITEM, 
		LAST);

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ieonline.microsoft.com/iedomainsuggestions/ie11/suggestions.ru-RU", "Referer=", ENDITEM, 
		"Url=https://ieonline.microsoft.com/ieflipahead/ie10/rules.xml?mkt=ru-RU", "Referer=", ENDITEM, 
		LAST);

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("fwlink_3", 
		"URL=https://go.microsoft.com/fwlink/?LinkID=401135", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(14);

	web_submit_data("reservations.pl", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=London", ENDITEM, 
		"Name=departDate", "Value=07/23/2019", ENDITEM, 
		"Name=arrive", "Value=Los Angeles", ENDITEM, 
		"Name=returnDate", "Value=07/29/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		"Name=findFlights.x", "Value=40", ENDITEM, 
		"Name=findFlights.y", "Value=13", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=230;1449;07/23/2019", ENDITEM, 
		"Name=returnFlight", "Value=320;1449;07/29/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=reserveFlights.x", "Value=39", ENDITEM, 
		"Name=reserveFlights.y", "Value=9", ENDITEM, 
		LAST);

	lr_think_time(11);

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=7869", ENDITEM, 
		"Name=address2", "Value=4567", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=23", ENDITEM, 
		"Name=expDate", "Value=45", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=outboundFlight", "Value=230;1449;07/23/2019", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=320;1449;07/29/2019", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		"Name=buyFlights.x", "Value=63", ENDITEM, 
		"Name=buyFlights.y", "Value=11", ENDITEM, 
		LAST);

	web_submit_data("reservations.pl_4", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=Book Another.x", "Value=48", ENDITEM, 
		"Name=Book Another.y", "Value=15", ENDITEM, 
		LAST);

	lr_end_transaction("23",LR_AUTO);

	return 0;
}